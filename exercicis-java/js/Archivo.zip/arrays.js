/**Arrays o matrices 
 * usado spara armazenar datos, variaveis, valores en un solo lugar.
 * No tiene propiedad, sus itens son en contate.
 * Se crean con [], y se separan por comas. Además se valida por posicion de 0 a cuantos datos ingrese.
 * Ejemplo:
 * Voy a supermercado y tengo una lista de cosas a comprar:
 *  - Leche
 *  - Pan
 *  - Huevos
 *  - Arroz
 *  - Agua
 *  - Jugo
 *  - Café
 *  - Azucar
 * practicamente es una lista de cosas que van desde su punto 0 - leche hacia el punto 7 que es azucar.
 * Pasando a codigo:
 */
const listaDeCompras = [
  "leche",
  "pan",
  "huevos",
  "arroz",
  "agua",
  "jugo",
  "café",
  "azucar",
]; //esta es la validación de nuestro arrays.
console.log(listaDeCompras);
console.log(listaDeCompras[0]); //imprime el primer elemento de la lista
console.log(listaDeCompras.length); //imprime la cantidad de elementos que tiene el array.
console.log(listaDeCompras[listaDeCompras.length - 1]); //imprime el ultimo elemento de la lista
// Caso queremos cambiar el valor ejemplo cambiar jugo por coca
listaDeCompras[5] = "coca";
console.log(listaDeCompras[5]); // va imprimir coca ya que cambiamos el jugo por coca
//Y se quiseramos adicionar dado
listaDeCompras.push("papel"); //adiciona un elemento al final del array
console.log(listaDeCompras); //va nos dar 9 iteins a mas. (leche, pan, huevos, arroz, agua, coca, azucar, papel)
//Y se ahora queremos validar si la matriz es o no una matriz
console.log(Array.isArray(listaDeCompras)); //nos retornará true porque es una matriz.
//Y se ahora queremos validar si la matriz es o no una matriz
console.log(listaDeCompras instanceof Array); //nos retornará true porque es una matriz.
//ambos los metodos se valida la matriz.

console.clear();

/**Passamos a los metodos de Arrays 
 *Los metodos son la funcion de una array que dentro de ella se encuentra la funcion que se va a ejecutar.
 * Es como decirnos a array que queremos hacer.
 * Ejemplo: passamos datos a una secuencia incorrecta de numeros: 30, 75, 10, 1, 5, 100, 25, 45, 95 y 105.
 * 
 */
const num = [ 30, 75, 10, 1, 5, 100, 25, 45, 95, 105];
console.log(num);

//Adicion------------------------------------
//Queremos hacer una adicion de mas 2 numeros al final de la lista.
num.push(2, 3); //adiciona 2 elementos al final de la lista
console.log(num); //Nos retorna los 2 numeros a la lista siendo 12 itens pero con 11 posiciones.
//Hagamos mas 3 adiciones.
num.push(5, 80, 95); //adiciona 3 elementos al final de la lista teniendo 15 itens pero con 14 posiciones.
//Ahora queremos adicionar otro elemento a lista pero en comiezo de la lista.
num.unshift(35); //adiciona 1 elemento al inicio de la lista.

//Delet-----------------------------------
// Pero esta lista esta enorme 15 itens y no queremos que sean 15 itens.
// Para eso usamos el metodo pop.
num.pop(); //elimina el ultimo elemento de la lista.
//Supiera que no era solo el ultimo que queria sacarlo pero tambien el primero
num.shift(); //elimina el primer elemento de la lista.

//Ahora queremos buscar un elemento especifico en la lista
//consultamos si el 20 existe
console.log(num.includes(20)); //nos va tomar como false que no existe
console.log(num.includes(80)); //nos va dar true que si existe
//Con el metodo includes podemos decir si existe el numero 20 nos mostra si no no, como en un bucle.

//Buscamos el indice de un elemento en la lista
console.log(num.indexOf(80)); //va mostrar el 13 porque es lo ultimo elemento de la lista.
//Y si queremos saber en que posicion esta el elemento.

//Ahora vamos a los metods de cortar los elementos.
//Vamos a cortar desde el indice 2 hasta el indice 4.
console.log(num.slice(2, 5)); //nos va mostrar el 10, 1, 5
console.log(num.slice(2, 13)); //nos va mostrar el 10, 1, 5, 100, 25, 45, 95, 105, 2, 3, 5

//Tenemos el metodo Join que va cambiar la lista o su espacio cuando la imprimimos en html y sera una cadena de texto. 
// se escribe num.jois (', ')
console.log(num.join(' - '));
